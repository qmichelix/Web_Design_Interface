function changeImageM1(url, nom) {
  console.log("DEBUG : changeImageM1 : url = "+url+", nom = "+nom);
imgTag.src=url;
bTag.innerHTML=nom;

}

function changeImageM2(id_url, id_nom, url, nom) {
  console.log("DEBUG : changeImageM2 : id_url = " + id_url + ", id_nom = " + id_nom
              +", url = " + url + ", nom = " + nom);
    var img = document.getElementById(id_url);
    var id = document.getElementById(id_nom);
    imgTag.src=url ;
    id.innerHTML= nom ;
}

function changeImageM3(url, nom) {
  console.log("DEBUG : changeImageM3 : url ="+url+" , nom = "+nom);
  var el = document.querySelector("#id_image");
  var le = document.querySelector("#id_quoi");
  el.src=url ;
  le.innerHTML=nom ;


  function changeCouleurDeFond()
  {
    var rgb = [Math.floor(Math.random()* 255), Math.floor(Math.random()* 255), Math.floor(Math.random()* 255)];
    var rgbfinal =[rgb[0],rgb[1], rgb[2]];
    document.body.style.backgroundColor = "rgb("+ rgbfinal.join(",")+ ")";
    document.oncontextmenu = new Function("return false");
  }
