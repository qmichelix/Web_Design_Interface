// connexion.js
// auteurs : Michelix, Boussez-Doussinez

//----------------------------------------------------- Variables globales ---
let codeChiffres = "";
let capchaFormule = "";
let capchaResultat = ""

//--------------------------------------------------------- Initialisation ---

// appelle la fonction d'Initialisation quand la fenêtre est chargée
window.addEventListener("load", init);

function init() {

  // Code d'accès
  melangeChiffres();
  afficheCode();

  // Capcha
  genereCapcha();

}
//----------------------------------------------- Gestion de l'identifiant ---

// renvoie vrai si la longueur de l'identifiant saisi est >= 8 caractères
function verifieIdentifiant() {
  let identifiant = document.getElementById("input_identifiant").value;
  return identifiant.length >= 8;
}

// modifie la couleur de l'identifiant en fonction de sa validité
function valideIdentifiant() {
  let identifiantElt = document.getElementById("input_identifiant");
  if (verifieIdentifiant() === true) {
    identifiantElt.style = "color:black;"
  } else {
    identifiantElt.style = "color:red;"
  }
}

//------------------------------------------------ Gestion du code d'accès ---

function melangeChiffres() {
  // récupère un tableau de boutons chiffres
  let divElt = document.getElementById("boutons_chiffres");
  let buttonElts = divElt.getElementsByTagName("button");

  // créer un tableau qui contient autant de chiffres que de boutons
  let tabChiffres = []; // tablean vide;
  for (let i = 0; i < buttonElts.length; i++) {
    tabChiffres[i] = i;
  }

  // mélanger ce tableau de chiffres
  melangeTableau(tabChiffres);

  // affecter ces chiffres mélangés sur les boutons
  for (let i = 0; i < buttonElts.length; i++) {
    buttonElts[i].textContent = tabChiffres[i];
  }
}

function melangeTableau(tab) {
  let i;
  let j;
  let temp;
  for (i = tab.length - 1; i > 0; i--) {
    j = Math.floor(Math.random() * (i + 1));
    temp = tab[i];
    tab[i] = tab[j];
    tab[j] = temp;
  }
}

function saisieChiffre(elt) {
  let chiffre = elt.textContent;


  codeChiffres = codeChiffres + chiffre

  document.getElementById("code_saisi").value=codeChiffres;

  console.log("Chiffre saisi : "+ chiffre);

  afficheCode();
}


function afficheCode() {
  console.log("Code à afficher : " + codeChiffres);
  document.getElementById("code_affiché").textContent=codeChiffres;
}

function supprimeChiffre() {
  let long = codeChiffres.length;
  codeChiffres = codeChiffres.slice(0,long-1);

  afficheCode()
}

function videCode() {
  codeChiffres = "";
  afficheCode();
}

//------------------------------------------------------ Gestion du Capcha ---

function genereCapcha() {
  var operations = ['+', '-', '*'];
  var o = parseInt(Math.round(Math.random() * 2));
  console.log("Opération choisie pour le capcha : " + operations[o]);

  var operande1 = parseInt(Math.round(Math.random() * 10));
  var operande2 = parseInt(Math.round(Math.random() * 10));

  var formule  = operande1 + " " + operations[o] + " " + operande2 + " = ";
  if (o==0) {
    var resultat = operande1 + operande2;
  }
  else
    if (o==1) {
      var resultat = operande1 - operande2;
    }
    else
      if (o==2) {
        var resultat = operande1 * operande2;
      }

  capchaFormule  = formule;
  capchaResultat = resultat;

  afficheCapcha();
}

function afficheCapcha() {
  let labelElt = document.getElementById("capcha_formule");
  labelElt.textContent = capchaFormule;
  let inputElt = document.getElementById("capcha_saisi").value = "";
}

function verifieCapcha() {
  let capchaElt = document.getElementById("capcha_saisi").value;
  return capchaElt==capchaResultat;
}

// modifie la couleur de l'identifiant en fonction de sa validité
function valideCapcha() {
  let identifiantElt = document.getElementById("capcha_saisi");
  if (verifieCapcha() === true) {
    identifiantElt.style = "color:black;"
    return true;
  } else {
    identifiantElt.style = "color:red;"
    return false;
  }
}

//----------------------------------------------- Validation du formulaire ---

function valideFormulaire() {
  let ok = true;
  if (verifieIdentifiant()===false) {
    console.log("L'identifiant doit comporter au moins 8 caractères !");
    ok = false;
  }
  if (codeChiffres.length!=6) {
    console.log("Le mot de passe doit être de 6 !");
    ok = false;
  }
  if (valideCapcha()===false) {
    console.log("Le capcha n'est pas correct !")
    ok = false
  }
  return ok;
}
